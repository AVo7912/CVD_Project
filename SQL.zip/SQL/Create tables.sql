CREATE TABLE generalhealth (
    UniqueID INT NOT NULL,
	General_Health VARCHAR (20) NOT NULL,
	Checkup VARCHAR (30) NOT NULL,
	Exercise VARCHAR (10) NOT NULL,
	Heart_Disease VARCHAR (10) NOT NULL,
	Skin_Cancer VARCHAR (10) NOT NULL,
	Other_Cancer VARCHAR (10) NOT NULL,
	Depression VARCHAR (10) NOT NULL,
	Diabetes VARCHAR (50) NOT NULL,
	Arthritis VARCHAR (10) NOT NULL,
	Sex VARCHAR (15) NOT NULL,
	Age_Category VARCHAR (10) NOT NULL,
	Height_cm FLOAT NOT NULL,
	Weight_kg FLOAT NOT NULL,
	BMI FLOAT NOT NULL,
	Smoking_History VARCHAR (10) NOT NULL,
    PRIMARY KEY (UniqueID)
	);
	
	CREATE TABLE health_consumption (
    UniqueID INT NOT NULL,
	Alcohol_Consumption FLOAT NOT NULL,
	Fruit_Consumption FLOAT NOT NULL,
	Green_Vegetables_Consumption FLOAT NOT NULL,
	FriedPotato_Consumption FLOAT NOT NULL,
    PRIMARY KEY (UniqueID)
	);
	
select * from health_consumption

Select * from generalhealth
